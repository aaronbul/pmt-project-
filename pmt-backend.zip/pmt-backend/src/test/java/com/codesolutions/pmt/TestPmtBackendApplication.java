package com.codesolutions.pmt;

import org.springframework.boot.SpringApplication;

public class TestPmtBackendApplication {

	public static void main(String[] args) {
		SpringApplication.from(PmtBackendApplication::main).with(TestcontainersConfiguration.class).run(args);
	}

}
