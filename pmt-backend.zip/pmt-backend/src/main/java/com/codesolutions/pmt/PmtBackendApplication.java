package com.codesolutions.pmt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PmtBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(PmtBackendApplication.class, args);
	}

}
